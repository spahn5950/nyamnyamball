const V='nyamball-mwh81o3r';
const FILES=["./","index.html","fonts.css","manifest.webmanifest","apple-touch-icon.png","icon-192.png","icon-512.png","fonts/jua-0.woff2","fonts/jua-1.woff2","fonts/jua-10.woff2","fonts/jua-11.woff2","fonts/jua-12.woff2","fonts/jua-13.woff2","fonts/jua-14.woff2","fonts/jua-15.woff2","fonts/jua-16.woff2","fonts/jua-17.woff2","fonts/jua-18.woff2","fonts/jua-19.woff2","fonts/jua-2.woff2","fonts/jua-20.woff2","fonts/jua-21.woff2","fonts/jua-3.woff2","fonts/jua-4.woff2","fonts/jua-5.woff2","fonts/jua-6.woff2","fonts/jua-7.woff2","fonts/jua-8.woff2","fonts/jua-9.woff2"];
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==V).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',e=>{
  if(e.request.method!=='GET')return;
  e.respondWith(caches.match(e.request,{ignoreSearch:true}).then(r=>r||fetch(e.request).then(res=>{const c=res.clone();caches.open(V).then(x=>x.put(e.request,c));return res;}).catch(()=>caches.match('index.html'))));
});
